"""
Bangladesh 2022: labour force, disability, child labour, literacy and vocational training
ONE merged Streamlit dashboard (3D + 2D charts, statistics, machine learning).

Run:      pip install -r requirements.txt
          streamlit run streamlit_app.py

Keep these files in the same folder:
  streamlit_app.py, labour_core.py, lfs_core.py
  CLFS_2022_DILFS_2022_LFS_2022.csv   labour force / disability / child labour tables  (NCLS + LFS Ch.8 + DILFS Ch.4)
  DILFS_2022_LFS_2022.csv             literacy & vocational-training tables            (DILFS Ch.3 + LFS Ch.4)
Either CSV can instead be uploaded from the sidebar ("Data files"). Sections that need a missing CSV say so
and the rest of the dashboard keeps working.
"""
import io
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from labour_core import *          # noqa: F401,F403  (helpers, question builders, make_charts, STYLES ...)
import lfs_core as c               # literacy / training loader, shared tables and ML pipeline

st.set_page_config(page_title="Bangladesh Labour Force, Literacy & Training 2022", page_icon="📊", layout="wide")

HERE = Path(__file__).resolve().parent
LAB_CSV = HERE / "CLFS_2022_DILFS_2022_LFS_2022.csv"
LIT_CSV = HERE / "DILFS_2022_LFS_2022.csv"
LIT_NAME = LIT_CSV.name

# Streamlit >= 1.50 uses width="stretch"; older releases use use_container_width=True
try:
    _NEW = tuple(int(x) for x in st.__version__.split(".")[:2]) >= (1, 50)
except ValueError:
    _NEW = False
STRETCH = {"width": "stretch"} if _NEW else {"use_container_width": True}


def plot(fig, key=None, target=st):
    target.plotly_chart(fig, key=key, **STRETCH)


def dframe(d, **kw):
    st.dataframe(d, **STRETCH, **kw)


# ----------------------------------------------------------------------------- data loading
@st.cache_data(show_spinner=False)
def load_labour(src):
    buf = io.BytesIO(src) if isinstance(src, bytes) else src
    validate_columns(pd.read_csv(buf, nrows=0, encoding="utf-8-sig"), LABOUR_REQUIRED, "labour-force")
    if isinstance(buf, io.BytesIO):
        buf.seek(0)
    return load_data(buf)


@st.cache_data(show_spinner=False)
def load_literacy(src):
    buf = io.BytesIO(src) if isinstance(src, bytes) else src
    validate_columns(pd.read_csv(buf, nrows=0, encoding="utf-8-sig"), LITERACY_REQUIRED, "literacy & training")
    if isinstance(buf, io.BytesIO):
        buf.seek(0)
    return c.load(buf)


@st.cache_data(show_spinner="Training the five models…")
def get_ml(_df, key):
    r = c.run_ml(_df)
    from sklearn.tree import export_text
    r["tree_text"] = export_text(r["small_tree"], feature_names=list(r["X"].columns))
    r.pop("models")
    r.pop("small_tree")          # sklearn objects are not needed after this point
    return r


def read_source(uploaded, default_path, loader):
    """Return (dataframe | None, message). Uploaded file wins over the file next to the app."""
    try:
        if uploaded is not None:
            return loader(uploaded.getvalue()), None
        if default_path.exists():
            return loader(str(default_path)), None
        return None, f"**{default_path.name}** was not found next to the app. Put it there, or upload it in the sidebar (Data files)."
    except Exception as e:  # wrong file, bad encoding ...
        return None, f"Could not read the file: {e}"


# ----------------------------------------------------------------------------- sidebar
SECTIONS = ["Dashboard", "Labour force & disability", "Child labour", "Literacy & training",
            "Machine learning", "Statistics & data quality", "Chart studio"]
with st.sidebar:
    st.title("📊 Labour force 2022")
    st.caption("NCLS · LFS · DILFS 2022, Bangladesh Bureau of Statistics")
    section = st.radio("Section", SECTIONS, key="section")
    st.markdown("---")
    icls = st.radio("ICLS framework (disability tables)", ["13th", "19th"], horizontal=True, key="icls",
                    help="13th ICLS counts all employed incl. own-use production; 19th ICLS is the stricter definition.")
    if section in ("Literacy & training",):
        sex_sel = st.radio("Sex", ["Total", "Male", "Female"], horizontal=True, key="sex")
        loc_sel = st.radio("Locality (general population)", ["National", "Rural", "Urban"], horizontal=True, key="loc",
                           help="The disability survey reports national figures only, so it always shows the national value.")
    else:
        sex_sel, loc_sel = "Total", "National"
    with st.expander("Data files (optional uploads)"):
        up_lab = st.file_uploader("Labour-force CSV (CLFS_2022_DILFS_2022_LFS_2022.csv)", type="csv", key="up_lab")
        up_lit = st.file_uploader(f"Literacy & training CSV ({LIT_NAME})", type="csv", key="up_lit")
    st.markdown("---")
    st.markdown("**Reading the charts**  \n3D charts rotate by dragging; click a legend item to hide it.")
    st.caption("Mst. Najnin Sultana · Fundamentals of Machine Learning · National University, Bangladesh")

lab, lab_msg = read_source(up_lab, LAB_CSV, load_labour)
lit_df, lit_msg = read_source(up_lit, LIT_CSV, load_literacy)
lit_key = (up_lit.name if up_lit is not None else "default", None if lit_df is None else len(lit_df))


def need_labour():
    if lab is None:
        st.error(lab_msg)
        st.stop()


def need_literacy():
    if lit_df is None:
        st.info("🔒 This section uses the literacy & vocational-training tables (DILFS Chapter 3 + LFS Chapter 4).  \n" + lit_msg)
        st.stop()


# ----------------------------------------------------------------------------- chart helpers
def show(data, title, key, default="Bar (vertical)", unit="", cmap=None):
    """Chart with a style switch: 3D pie, 2D pie, bars, horizontal bars, stacked bars, 3D bars, 3D cylinders."""
    style = st.radio("Chart style", STYLES, index=STYLES.index(default), horizontal=True, key=key)
    figs = make_charts(data, style, title, unit, cmap)
    if len(figs) > 1:
        cs = st.columns(min(3, len(figs)))
        for i, f in enumerate(figs):
            plot(f, f"{key}_{i}", cs[i % len(cs)])
    else:
        plot(figs[0], f"{key}_0")


def table(data, key, fmt="{:,.2f}"):
    with st.expander("Data table / download"):
        st.dataframe(data.style.format(fmt, na_rep="–"), **STRETCH)
        st.download_button("Download CSV", data.to_csv().encode("utf-8-sig"), f"{key}.csv", "text/csv", key="dl_" + key)


def gap(msg):
    st.warning("**Not in the supplied data:** " + msg)


def metric(col, label, value, note=None):
    """Metric tile; the comparison goes in a caption (a metric 'delta' would show a misleading up-arrow)."""
    col.metric(label, value)
    if note:
        col.caption(note)


def two_d_three_d(data, title, key, unit, style2d, style3d, cmap=None):
    """Same numbers drawn twice: one 2D chart, one 3D chart (each with its own style switch)."""
    show(data, title + " (2D)", key + "_2d", style2d, unit, cmap)
    show(data, title + " (3D)", key + "_3d", style3d, unit, cmap)


# ============================================================================= DASHBOARD
def render_dashboard():
    need_labour()
    st.title("Bangladesh 2022: work, disability, child labour, literacy and training")
    st.caption("One-page summary. Pick a section in the sidebar for the full analysis of each topic.")
    ps = participants_summary(lab).set_index("Indicator")
    ur = q4_unemp_rate(lab, icls)
    part = q4_participation(lab, icls)["Labour force participation rate"]
    k = st.columns(5)
    k[0].metric("Labour force (thousand)", f"{ps.loc['Labour force (15+, 13th ICLS)', 'Total']:,.0f}")
    metric(k[1], "Unemployment rate", f"{ur.loc['Total', 'Total']:.2f}%", f"with disabilities: {ur.loc['With disabilities', 'Total']:.2f}%")
    metric(k[2], "Participation, with disabilities", f"{part.loc['With disabilities', 'Total']:.1f}%",
           f"without disabilities: {part.loc['Without disabilities', 'Total']:.1f}%")
    k[3].metric("Women's share of labour force", f"{ps.loc['Labour force (15+, 13th ICLS)', 'Female share %']:.1f}%")
    k[4].metric("Working children 5-17", f"{ps.loc['Working children 5-17', 'Total'] / 1e6:.2f} M")
    if lit_df is not None:
        lt, tr = c.literacy_table(lit_df), c.training_rate(lit_df)
        k2 = st.columns(5)
        k2[0].metric("Literacy – disabled", f"{lt.loc['Total', 'Disabled']:.1f}%")
        k2[1].metric("Literacy – general", f"{lt.loc['Total', 'General']:.1f}%")
        metric(k2[2], "Literacy gap", f"{lt.loc['Total', 'Gap']:.1f} pts", f"women {lt.loc['Female', 'Gap']:.1f} · men {lt.loc['Male', 'Gap']:.1f}")
        k2[3].metric("Trained – disabled", f"{tr.loc['Total', 'Disabled']:.2f}%")
        k2[4].metric("Trained – general", f"{tr.loc['Total', 'General']:.2f}%")
    else:
        st.info("Literacy and training indicators appear here once **" + LIT_NAME + "** is available (see Data files in the sidebar).")

    mode = st.radio("Chart dimension for the grid below", ["2D", "3D"], horizontal=True, key="dash_mode")
    d3 = mode == "3D"

    def cell(col, data, title, unit, s2, s3, cmap=None, key=""):
        for i, f in enumerate(make_charts(data, s3 if d3 else s2, title, unit, cmap)):
            f.update_layout(height=380 if not d3 else 430)
            plot(f, f"dash_{key}_{i}", col)

    eu = q1_emp_unemp(lab, icls)
    rate = q2_age_area(lab, "rate").drop(index="Total")["Bangladesh"][["Male", "Female", "Total"]]
    cnt = q2_age_area(lab, "count")
    sec = q5_sector(lab)
    re_ = q8_unemp_by_education(lab)[0].drop(index="Total")["Bangladesh"][["Male", "Female", "Total"]]
    _, sh = q9_child_industry(lab)
    top = sh[["Under 15 (5-13)", "14-17"]].sort_values("Under 15 (5-13)", ascending=False).head(6)
    _, p10 = q10_school(lab)

    a, b = st.columns(2)
    cell(a, eu[["Total"]], "Employed vs unemployed (thousand)", "thousand", "2D pie", "3D pie", key="eu")
    cell(b, rate, "Unemployment rate by age group (%)", "%", "Bar (vertical)", "3D bar", key="age")
    a, b = st.columns(2)
    cell(a, part.loc[["With disabilities", "Without disabilities"], ["Male", "Female", "Total"]],
         "Labour force participation by disability (%)", "%", "Bar (vertical)", "3D bar", key="lfpr")
    cell(b, ur.loc[["With disabilities", "Without disabilities"]], "Unemployment rate by disability (%)", "%",
         "Bar (vertical)", "3D cylindrical bar", key="ur")
    a, b = st.columns(2)
    cell(a, sec[["Total"]], "Sector of workers with disabilities (%)", "%", "2D pie", "3D pie", key="sec")
    cell(b, re_, "Unemployment rate by education (%)", "%", "Bar (vertical)", "3D bar", key="edu")
    a, b = st.columns(2)
    cell(a, top, "Working children by industry (% within age band)", "%", "Rectangular bar (horizontal)", "3D bar", key="ind")
    cell(b, p10.T, "School attendance of working children (%)", "%", "Stacked bar", "3D bar", key="sch")
    if lit_df is not None:
        lt = c.literacy_table(lit_df)
        a, b = st.columns(2)
        cell(a, lt[["General", "Disabled"]], "Literacy rate by sex (%)", "%", "Bar (vertical)", "3D bar", key="lit")
        cell(b, pair_table(c.types(lit_df), c.TYPE_ORDER).head(6), "Training types, national (% of trained)", "%",
             "Rectangular bar (horizontal)", "3D bar", key="trt")

    with st.expander("Key findings (computed from the data)"):
        yth = cnt.loc["15-24", ("Bangladesh", "Total")] / cnt.loc["Total", ("Bangladesh", "Total")] * 100
        st.markdown(
            f"- Ages 15-24 are **{yth:.0f}%** of all unemployed persons.\n"
            f"- Unemployment is almost equal by sex ({ur.loc['Total', 'Male']:.1f}% men, {ur.loc['Total', 'Female']:.1f}% women), "
            f"but women are only **{ps.loc['Labour force (15+, 13th ICLS)', 'Female share %']:.0f}%** of the labour force.\n"
            f"- People with disabilities have a lower unemployment rate ({ur.loc['With disabilities', 'Total']:.2f}% vs "
            f"{ur.loc['Without disabilities', 'Total']:.2f}%) **and** far lower participation ({part.loc['With disabilities', 'Total']:.1f}% vs "
            f"{part.loc['Without disabilities', 'Total']:.1f}%).\n"
            f"- Unemployment is highest at tertiary education ({re_.loc['Tertiary', 'Total']:.1f}%), not at the lowest education level.")
        if lit_df is not None:
            lt, tr = c.literacy_table(lit_df), c.training_rate(lit_df)
            st.markdown(f"- Literacy gap between the general population and persons with disabilities: **{lt.loc['Total', 'Gap']:.1f} points** "
                        f"(women {lt.loc['Female', 'Gap']:.1f}, men {lt.loc['Male', 'Gap']:.1f}); trained: {tr.loc['Total', 'Disabled']:.2f}% vs {tr.loc['Total', 'General']:.2f}%.")

    st.subheader("Summary of male / female participants")
    dframe(participants_summary(lab).style.format({"Male": "{:,.2f}", "Female": "{:,.2f}", "Total": "{:,.2f}", "Female share %": "{:.1f}"}), hide_index=True)
    st.subheader("Unemployed persons by sex and area (thousand)")
    dframe(pd.concat({"Area": sex_area_summary(lab)[AREAS]}, axis=1).style.format("{:,.0f}"))
    st.subheader("Dataset structure (rows, columns, merged column groups)")
    dframe(dataset_structure(lab))


# ============================================================================= LABOUR FORCE & DISABILITY
def render_labour():
    need_labour()
    st.title("Labour force and disability")
    t = st.tabs(["1 · Employed vs unemployed", "2 · Age & area", "3 · Outside labour force", "4 · Unemployment rate",
                 "5 · Economic sector", "6 · Self-employment", "7 · Education"])
    with t[0]:
        st.subheader("Employed vs unemployed labour force by sex, and the disabled labour force (15+)")
        grp = st.radio("Population", ["Total", "With disabilities", "Without disabilities"], horizontal=True, key="q1grp")
        eu = q1_emp_unemp(lab, icls, grp)
        show(eu, f"Employed vs unemployed — {grp.lower()} ({icls} ICLS)", "q1a", "3D pie", "thousand")
        table(eu, "q1_employed_unemployed")
        st.markdown("##### Share of employed/unemployed (%) of the labour force")
        dframe((eu / eu.loc[["Employed", "Unemployed"]].sum() * 100).round(2).style.format("{:.2f}"))
        st.markdown("---")
        dl = q1_disabled_lf(lab, icls)
        show(dl, f"Labour force by disability status ({icls} ICLS)", "q1b", "3D pie", "thousand")
        show(dl.loc[["With disabilities"], ["Male", "Female"]].T, "Labour force with disabilities — male vs female", "q1c", "3D pie", "thousand")
        table(dl, "q1_disabled_labour_force")
    with t[1]:
        st.subheader("Age groups (15-24 … 55-64) by area and sex")
        gap("employed counts by age group and any age × disability cross-tabulation. LFS Chapter 8 publishes unemployed "
            "persons and unemployment rates by age/sex/area only, so this tab shows those.")
        m1, m2 = st.columns(2)
        measure = m1.radio("Measure", ["Unemployed persons (thousand)", "Unemployment rate (%)"], horizontal=True)
        area = m2.radio("Area", AREAS, horizontal=True, index=2)
        w = q2_age_area(lab, "count" if measure.startswith("Unemployed") else "rate")
        unit = "thousand" if measure.startswith("Unemployed") else "%"
        show(w.drop(index="Total")[area][["Male", "Female", "Total"]], f"{measure} by age group — {area}", "q2a", "3D bar", unit)
        show(w.drop(index="Total").xs("Total", axis=1, level=1)[AREAS], f"{measure} by age group — rural vs urban (both sexes)", "q2b", "Bar (vertical)", unit)
        st.markdown("##### Rural vs urban × male / female (merged headers)")
        dframe(w.style.format("{:,.2f}"))
        st.download_button("Download CSV", w.to_csv().encode("utf-8-sig"), "q2_age_area.csv", "text/csv")
    with t[2]:
        st.subheader("Outside the labour force: with vs without disability, by sex")
        meas = st.radio("Measure", ["percent", "thousands"], horizontal=True, key="q3m",
                        format_func=lambda x: "Share of population outside LF (%)" if x == "percent" else "Persons (thousand)")
        o = q3_outside_lf(lab, icls, meas)
        show(o, f"Outside labour force — {icls} ICLS", "q3", "3D cylindrical bar", "%" if meas == "percent" else "thousand")
        table(o, "q3_outside_lf")
    with t[3]:
        st.subheader("Unemployment rate and participation: persons with vs without disabilities")
        ur = q4_unemp_rate(lab, icls)
        show(ur, f"Unemployment rate (15+) — {icls} ICLS", "q4", "3D bar", "%")
        table(ur, "q4_unemployment_rate")
        ratio = (ur.loc["Without disabilities"] / ur.loc["With disabilities"]).round(2)
        st.caption("Rate ratio (without ÷ with disabilities): " + ", ".join(f"{kk} {v}×" for kk, v in ratio.items()) +
                   ". A low measured unemployment rate coexists with very low participation (below).")
        for name, part in q4_participation(lab, icls).items():
            show(part[["Male", "Female", "Total"]], f"{name} ({icls} ICLS)", "q4_" + name[:3], "Bar (vertical)", "%")
    with t[4]:
        st.subheader("Prominent economic sectors — employed persons with disabilities, by sex")
        gap("the same sector split for the labour force WITHOUT disabilities (DILFS Table 4.7 covers persons with disabilities only).")
        sec = q5_sector(lab)
        show(sec, "Employment by main economic sector (%) — persons with disabilities", "q5", "3D pie", "%")
        table(sec, "q5_sector")
    with t[5]:
        st.subheader("Self-employment and own business — employed persons with disabilities")
        gap("freelancing as a separate category; the urban/rural split; and the comparison with persons without disabilities. "
            "'Own-account worker' + 'Employer' is used as the self-employment measure.")
        pct, thou, se, inf = q6_status(lab)
        show(pct, "Status in employment (%)", "q6a", "Bar (vertical)", "%")
        st.markdown("**Self-employed share (own-account + employer), % of employed persons with disabilities**")
        dframe(se.style.format("{:.2f}"))
        show(inf[["Male", "Female", "Total"]], "Informal vs formal employment (%)", "q6b", "3D pie", "%")
        table(thou, "q6_status_thousands")
    with t[6]:
        st.subheader("Unemployment by education level")
        gap("unemployment after vocational training — none of the labour-force tables report training status. "
            "The literacy & training section covers training participation separately.")
        rate, cnt, lit_t = q8_unemp_by_education(lab)
        a = st.radio("Area", AREAS, horizontal=True, index=2, key="q8a")
        show(rate.drop(index="Total")[a][["Male", "Female", "Total"]], f"Unemployment rate by education — {a}", "q8a_chart", "3D bar", "%")
        show(cnt.drop(index="Total")[a][["Male", "Female", "Total"]], f"Unemployed persons by education — {a}", "q8b_chart", "3D pie", "thousand")
        st.markdown("##### By literacy")
        dframe(lit_t.style.format("{:.2f}"))
        table(rate, "q8_rate_by_education")


# ============================================================================= CHILD LABOUR
def render_child():
    need_labour()
    st.title("Child labour (NCLS 2022)")
    t = st.tabs(["Industry, hours & income", "Schooling"])
    with t[0]:
        st.subheader("Working children (5-17) by industry — including under-15s")
        n, sh = q9_child_industry(lab)
        st.caption("'Under 15' = ages 5-11 + 12-13 combined. Source: NCLS 2022 Table 4.2.")
        grpc = st.multiselect("Age groups", list(sh.columns), default=["Under 15 (5-13)", "14-17"], key="q9g")
        if not grpc:
            st.warning("Pick at least one age group.")
        else:
            top = sh[grpc].assign(_m=sh[grpc].max(axis=1)).sort_values("_m", ascending=False).drop(columns="_m")
            show(top.head(8), "Share of working children by industry (%) — top 8", "q9a", "Rectangular bar (horizontal)", "%")
            show(top.head(8)[[grpc[0]]], f"Industry mix — {grpc[0]}", "q9b", "3D pie", "%")
        table(n, "q9_children_by_industry_counts", "{:,.0f}")
        st.markdown("---")
        st.markdown("##### Other child-labour indicators")
        area9 = st.radio("Area", AREAS, horizontal=True, index=2, key="q9area")

        def ncls_wide(tid):
            w = wide(tbl(lab, "NCLS 2022", tid))
            w.columns = pd.MultiIndex.from_tuples([("Bangladesh" if x == "Total" else x, y) for x, y in w.columns])
            return w.drop(index="Total")[area9][["Male", "Female", "Total"]]
        show(ncls_wide("Table 4.13"), f"Average weekly hours — {area9}", "q9c", "Bar (vertical)", "hours")
        show(ncls_wide("Table 4.16"), f"Average monthly income — {area9}", "q9d", "Bar (vertical)", "Tk.")
    with t[1]:
        st.subheader("Working children's schooling by age group")
        gap("a literacy rate for children. NCLS reports school attendance, shown here as the closest available proxy.")
        n, p = q10_school(lab)
        show(p.T, "School attendance status by age group (%)", "q10a", "Stacked bar", "%")
        ag = st.radio("Age group for pie", list(p.columns), index=3, horizontal=True, key="q10ag")
        show(p[[ag]], f"School attendance — ages {ag}", "q10b", "3D pie", "%")
        st.markdown("##### Reasons")
        which = st.radio("Reasons for", ["Never attended school (Table 4.7)", "Dropped out (Table 4.9)"], horizontal=True)
        show(q10_reasons(lab, "Table 4.7" if which.startswith("Never") else "Table 4.9"), which, "q10c", "Rectangular bar (horizontal)", "%")
        table(n, "q10_school_counts", "{:,.0f}")


# ============================================================================= LITERACY & TRAINING
def render_literacy():
    need_literacy()
    st.title("Literacy and vocational training")
    st.caption("Persons with disabilities (DILFS 2022) compared with the general population (LFS 2022). "
               f"Sex: **{sex_sel}** · general-population locality: **{loc_sel}** (change in the sidebar).")
    df2 = lit_df
    types_df, dur_df = c.types(df2), c.durations(df2)
    lt, tr = c.literacy_table(df2), c.training_rate(df2)
    k = st.columns(5)
    k[0].metric("Literacy – disabled", f"{lt.loc['Total', 'Disabled']:.1f}%")
    k[1].metric("Literacy – general", f"{lt.loc['Total', 'General']:.1f}%")
    metric(k[2], "Literacy gap", f"{lt.loc['Total', 'Gap']:.1f} pts", f"women {lt.loc['Female', 'Gap']:.1f} · men {lt.loc['Male', 'Gap']:.1f}")
    k[3].metric("Trained – disabled", f"{tr.loc['Total', 'Disabled']:.2f}%")
    k[4].metric("Trained – general", f"{tr.loc['Total', 'General']:.2f}%")
    t = st.tabs(["Literacy", "Training types", "Training duration", "Training source", "3D explorer"])
    with t[0]:
        st.subheader("Literacy rate by sex")
        two_d_three_d(lt[["General", "Disabled"]], "Literacy rate", "lit", "%", "Bar (vertical)", "3D bar")
        c1, c2 = st.columns(2)
        c1.markdown("**National literacy rate (%)**")
        c1.dataframe(lt.round(2).rename(columns={"Gap": "Gap (points)"}), **STRETCH)
        c2.markdown("**General population by locality (%)**")
        c2.dataframe(c.literacy_locality(df2).round(1), **STRETCH)
        st.subheader("General population: literacy by age group and sex")
        la = c.literacy_age(df2)
        two_d_three_d(la[["Male", "Female"]], "Literacy by age group", "lita", "%", "Bar (vertical)", "3D bar")
    with t[1]:
        st.subheader("Training type — share of trained persons (%)")
        tt = pair_table(types_df, c.TYPE_ORDER, sex_sel, loc_sel)
        two_d_three_d(tt, "Training type", "ttype", "%", "Rectangular bar (horizontal)", "3D bar")
        tab = tt.assign(**{"Difference (General − Disabled)": tt.General - tt.Disabled})
        st.markdown("**Table**")
        dframe(tab.round(2))
    with t[2]:
        st.subheader("Training duration — share of trained persons (%)")
        dd = pair_table(dur_df, c.DUR_ORDER, sex_sel, loc_sel)
        two_d_three_d(dd, "Training duration", "tdur", "%", "Bar (vertical)", "3D bar")
        c1, c2 = st.columns(2)
        c1.markdown("**Table**")
        c1.dataframe(dd.round(2), **STRETCH)
        short = dd.loc[["<1 week", "1-2 weeks", "3-4 weeks"]].sum()
        long_ = dd.loc[["4-6 months", ">6 months"]].sum()
        c2.markdown("**Short (< 1 month) vs long (≥ 4 months) courses**")
        c2.dataframe(pd.DataFrame({"< 1 month": short, "≥ 4 months": long_}).T.round(1), **STRETCH)
        st.subheader("3D view: duration × group and sex (national)")
        show(duration_group_sex(dur_df, c.DUR_ORDER), "Training duration by group and sex (%)", "tdur_gs", "3D bar", "%", GROUP_SEX_COLORS)
    with t[3]:
        st.subheader("Source of training (national, % of trained persons)")
        src = c.sources(df2)
        two_d_three_d(src, "Source of training", "tsrc", "%", "Rectangular bar (horizontal)", "3D pie")
        dframe(src.round(2))
    with t[4]:
        st.subheader("Interactive 3D explorer (drag to rotate, scroll to zoom)")
        topic = st.radio("Topic", ["Training type", "Training duration"], horizontal=True)
        d = types_df if topic == "Training type" else dur_df
        d = d[d.Sex != "Total"].copy()
        d["Category"] = d.Category.astype(str)
        d["Group-sex-locality"] = d.Pop + " · " + d.Sex + " · " + d.Locality
        order = c.TYPE_ORDER if topic == "Training type" else c.DUR_ORDER
        d["x"] = d.Category.map({kk: i for i, kk in enumerate(order)})
        glist = sorted(d["Group-sex-locality"].unique())
        d["y"] = d["Group-sex-locality"].map({kk: i for i, kk in enumerate(glist)})
        kind = st.radio("Chart type", ["3D scatter", "3D surface"], horizontal=True)
        colors = {"General": SEX_COLORS["General"], "Disabled": SEX_COLORS["Disabled"]}
        if kind == "3D scatter":
            fig = px.scatter_3d(d, x="x", y="y", z="Share", color="Pop", color_discrete_map=colors, symbol="Sex",
                                hover_data={"Category": True, "Group-sex-locality": True, "x": False, "y": False, "Share": ":.2f"})
        else:
            piv = d.pivot_table(index="Group-sex-locality", columns="Category", values="Share").reindex(columns=order)
            fig = go.Figure(go.Surface(z=piv.values, x=list(range(len(order))), y=list(range(len(piv))), colorscale="Viridis",
                                       hovertemplate="%{z:.2f}%<extra></extra>"))
            glist = list(piv.index)
        fig.update_layout(height=650, margin=dict(l=0, r=0, t=10, b=0), scene=dict(
            xaxis=dict(tickvals=list(range(len(order))), ticktext=order, title="Category"),
            yaxis=dict(tickvals=list(range(len(glist))), ticktext=glist, title=""), zaxis=dict(title="Share (%)")))
        plot(fig, "explorer")


# ============================================================================= MACHINE LEARNING
def render_ml():
    need_literacy()
    try:
        import sklearn  # noqa: F401
    except ImportError:
        st.error("The machine-learning section needs scikit-learn:  pip install scikit-learn")
        st.stop()
    st.title("Machine learning: predicting the share of trained persons")
    st.caption("Target = share (%) of one training type or duration band for a group × sex × locality. "
               "136 rows, 22 features, five regression models, 5-fold cross-validation.")
    ml = get_ml(lit_df, lit_key)
    t = st.tabs(["Preprocessing", "Model comparison", "Predicted vs actual", "Feature importance", "Decision tree"])
    with t[0]:
        st.subheader("Outlier check and capping")
        o = ml["outliers"].copy()
        o.columns = ["Topic", "Lower fence", "Upper fence", "IQR outliers", "Z-score outliers"]
        c1, c2 = st.columns([2, 3])
        c1.markdown("**Outliers (capped at the IQR fences)**")
        c1.dataframe(o.round(2), hide_index=True, **STRETCH)
        h = pd.concat([ml["frame"].assign(State="Before capping", V=ml["frame"].Share_raw),
                       ml["frame"].assign(State="After capping", V=ml["frame"].Share)])
        fig = px.histogram(h, x="V", color="State", barmode="overlay", nbins=25, opacity=.65, labels={"V": "Share (%)"},
                           color_discrete_sequence=[SEX_COLORS["Male"], SEX_COLORS["Female"]])
        fig.update_layout(height=300, margin=dict(t=10))
        plot(fig, "ml_hist", c2)
        st.caption(f"{len(ml['frame'])} rows · {ml['n_feat']} features · {ml['n_train']} train / {ml['n_test']} test rows · "
                   f"StandardScaler fitted on train only · seed {c.SEED}")
    with t[1]:
        st.subheader("Test-set performance")
        res = ml["results"]
        c1, c2 = st.columns([3, 2])
        c1.markdown("**Sorted by RMSE**")
        c1.dataframe(res.round(3), hide_index=True, **STRETCH)
        f = go.Figure()
        f.add_bar(x=res.Model, y=res.RMSE, name="RMSE", marker_color=SEX_COLORS["Female"])
        f.add_scatter(x=res.Model, y=res.R2, name="R²", yaxis="y2", mode="lines+markers", marker_color=SEX_COLORS["Male"])
        f.update_layout(height=330, yaxis2=dict(overlaying="y", side="right", title="R²"), yaxis=dict(title="RMSE (points)"),
                        legend=dict(orientation="h"), margin=dict(t=10))
        plot(f, "ml_res", c2)
        st.subheader("5-fold cross-validation")
        cvt = ml["cv"].copy()
        cvt.columns = ["Model", "Mean R²", "R² std dev"]
        c1, c2 = st.columns([2, 3])
        c1.dataframe(cvt.round(3), hide_index=True, **STRETCH)
        fig = px.bar(cvt, x="Model", y="Mean R²", error_y="R² std dev", color_discrete_sequence=[SEX_COLORS["Male"]])
        fig.update_layout(height=320, margin=dict(t=10))
        plot(fig, "ml_cv", c2)
    with t[2]:
        st.subheader("Predicted vs actual (test set)")
        names = list(ml["preds"].keys())
        model_choice = st.selectbox("Model", names, index=names.index("Random Forest"))
        te = ml["frame"].loc[ml["yte"].index].copy()
        te["Predicted"] = ml["preds"][model_choice]
        te["Actual"] = ml["yte"].values
        te["Group"] = te.Pop + " · " + te.Sex
        te["Abs error"] = (te.Actual - te.Predicted).abs()
        gcode = {"General · Male": 0, "General · Female": 1, "Disabled · Male": 2, "Disabled · Female": 3}
        te["GroupCode"] = te.Group.map(gcode)
        colors = {"General": SEX_COLORS["General"], "Disabled": SEX_COLORS["Disabled"]}
        c1, c2 = st.columns(2)
        fig = px.scatter(te, x="Actual", y="Predicted", color="Pop", color_discrete_map=colors, hover_data=["Category", "Locality", "Sex"])
        mx = float(max(te.Actual.max(), te.Predicted.max())) + 2
        fig.add_shape(type="line", x0=0, y0=0, x1=mx, y1=mx, line=dict(dash="dash", color="grey"))
        fig.update_layout(height=450, margin=dict(t=10))
        plot(fig, "ml_pa", c1)
        fig = px.scatter_3d(te, x="Actual", y="Predicted", z="GroupCode", color="Group", hover_data=["Category", "Locality", "Abs error"])
        fig.update_layout(height=450, margin=dict(l=0, r=0, t=10, b=0),
                          scene=dict(zaxis=dict(tickvals=list(gcode.values()), ticktext=["G-M", "G-F", "D-M", "D-F"], title="Group")))
        plot(fig, "ml_pa3d", c2)
        dframe(te[["Category", "Pop", "Sex", "Locality", "Actual", "Predicted", "Abs error"]].round(2), hide_index=True)
    with t[3]:
        st.subheader("Random Forest feature importance")
        imp = ml["importance"].head(12)[::-1]
        fig = px.bar(x=imp.values, y=imp.index, orientation="h", labels={"x": "Importance", "y": ""},
                     color_discrete_sequence=[SEX_COLORS["Female"]])
        fig.update_layout(height=420, margin=dict(t=10))
        plot(fig, "ml_imp")
        st.caption(f"Lasso set {ml['lasso_zero']} coefficient(s) to exactly zero.")
    with t[4]:
        st.subheader("Effect of tree depth")
        dp = ml["depth"].copy()
        dp["Depth"] = dp.Depth.astype(str)
        c1, c2 = st.columns([2, 3])
        c1.dataframe(dp.round(3), hide_index=True, **STRETCH)
        fig = px.line(dp.melt(id_vars="Depth", var_name="Set", value_name="R²"), x="Depth", y="R²", color="Set", markers=True,
                      color_discrete_sequence=[SEX_COLORS["Male"], SEX_COLORS["Female"], PALETTE[2]])
        fig.update_layout(height=340, margin=dict(t=10))
        plot(fig, "ml_depth", c2)
        st.subheader("3D surface: cross-validated R² over depth and minimum leaf size")
        g = ml["grid"].pivot(index="MinLeaf", columns="Depth", values="CV_R2")
        fig = go.Figure(go.Surface(z=g.values, x=list(g.columns), y=list(g.index), colorscale="Viridis", colorbar=dict(title="CV R²")))
        fig.update_layout(height=560, margin=dict(l=0, r=0, t=10, b=0),
                          scene=dict(xaxis_title="Max depth", yaxis_title="Min samples per leaf", zaxis_title="CV R²"))
        plot(fig, "ml_surface")
        best = ml["grid"].sort_values("CV_R2").iloc[-1]
        st.info(f"Best cross-validated R² = {best.CV_R2:.3f} at depth {int(best.Depth)} and minimum leaf size {int(best.MinLeaf)}.")
        st.subheader("Rules of the depth-3 tree")
        st.code(ml["tree_text"], language="text")


# ============================================================================= STATISTICS & DATA QUALITY
def render_stats():
    need_labour()
    st.title("Statistics and data quality")
    t = st.tabs(["Tests & trend", "Correlation", "Data quality"])
    with t[0]:
        st.markdown("**Is the male–female unemployment-rate gap significant?** Paired tests across age groups / education levels "
                    "(small n — read p-values as indicative).")
        dframe(male_female_tests(lab).style.format(precision=3), hide_index=True)
        st.markdown("**Unemployment-rate trend 2010 → 2022** (Figure 8.7; linear fit, only 5 survey rounds).")
        tw, _ = trend_table(lab)
        fig = go.Figure()
        for j, col in enumerate(tw.columns):
            fig.add_trace(go.Scatter(x=tw.index, y=tw[col], mode="lines+markers", name=col, line=dict(color=color_for(col, j), width=2),
                                     marker=dict(size=9)))
        fig.update_layout(height=380, xaxis_title="Survey year", yaxis_title="Unemployment rate (%)", margin=dict(t=20))
        plot(fig, "trend")
        dframe(trend_regression(lab).style.format(precision=4), hide_index=True)
    with t[1]:
        st.markdown("**Correlation of unemployment rates across age groups** (area × sex columns, Table 8.3.1)")
        cm = lfs(lab, "Table 8.3.1").drop(index="Total")
        cm.columns = [f"{a[:3]}·{b}" for a, b in cm.columns]
        hm = px.imshow(cm.corr().round(2), text_auto=True, color_continuous_scale="RdBu_r", zmin=-1, zmax=1, aspect="auto")
        hm.update_layout(height=520, margin=dict(t=20))
        plot(hm, "corr")
    with t[2]:
        st.subheader("Labour-force CSV")
        blanks, dups, outl = data_quality(lab)
        k = st.columns(3)
        k[0].metric("Rows", f"{len(lab):,}")
        k[1].metric("Duplicate keys", dups)
        k[2].metric("Missing values", int(lab.value.isna().sum()))
        st.markdown("Blank `row_group` / `column_group` / `table_note` cells are structural: not every table has them.")
        dframe(blanks)
        st.markdown(f"**IQR outliers** (non-total rows, per table and unit): {len(outl)} flagged — mostly genuinely large categories, not errors.")
        dframe(outl, hide_index=True)
        st.subheader("Literacy & training CSV")
        if lit_df is None:
            st.info(lit_msg)
        else:
            q = literacy_quality(lit_df)
            k = st.columns(4)
            k[0].metric("Rows", f"{q['rows']:,}")
            k[1].metric("Tables", sum(q["tables"].values()))
            k[2].metric("Missing values", q["missing"])
            k[3].metric("Duplicate keys", q["duplicates"])
            dframe(lit_df.groupby(["Source", "Table", "Table_Title"]).size().rename("rows").reset_index(), hide_index=True)


# ============================================================================= CHART STUDIO
def render_studio():
    st.title("Chart studio — any table, any chart style")
    st.caption("3D pie · 2D pie · bar · rectangular (horizontal) bar · stacked bar · 3D bar · 3D cylindrical bar")
    which = st.radio("Dataset", ["Labour force / disability / child labour", "Literacy & vocational training"], horizontal=True)
    if which.startswith("Labour"):
        need_labour()
        g1, g2, g3 = st.columns(3)
        sv = g1.selectbox("Survey", sorted(lab.survey.unique()))
        tids = list(dict.fromkeys(lab[lab.survey == sv].table_id))
        titles = {x: lab[(lab.survey == sv) & (lab.table_id == x)].table_title.iloc[0] for x in tids}
        tid = g2.selectbox("Table", tids, format_func=lambda x: f"{x} — {short(titles[x], 60)}")
        sub = tbl(lab, sv, tid)
        un = g3.selectbox("Unit / block", sorted(sub.unit.unique()))
        w = wide(sub[sub.unit == un])
        if isinstance(w.columns, pd.MultiIndex):
            w.columns = [f"{a} · {b}" for a, b in w.columns]
        w = w[~w.index.str.lower().str.startswith("total")]
        title = titles[tid]
    else:
        need_literacy()
        g1, g2, g3 = st.columns(3)
        tids = list(dict.fromkeys(lit_df.Table))
        titles = {x: f"{lit_df[lit_df.Table == x].Source.iloc[0]} · {lit_df[lit_df.Table == x].Table_Title.iloc[0]}" for x in tids}
        tid = g1.selectbox("Table", tids, format_func=lambda x: f"{x} — {short(titles[x], 70)}")
        sub = lit_df[lit_df.Table == tid]
        grp = g2.selectbox("Group / locality", sorted(sub.Group.unique()))
        sub = sub[(sub.Group == grp) & (sub.Category != "Total")]
        w = sub.pivot_table(index="Category", columns="Sex", values="Value", sort=False)
        un = "% / as published"
        title = titles[tid]
    if w.empty:
        st.warning("Nothing to plot for this selection.")
        return
    pickc = st.multiselect("Series (columns) to plot", list(w.columns), default=list(w.columns)[:3])
    pickr = st.multiselect("Categories (rows)", list(w.index), default=list(w.index)[:8])
    if pickc and pickr:
        show(w.loc[pickr, pickc], title, "gal", "3D cylindrical bar", un)
    table(w, "gallery")


# ============================================================================= router
{"Dashboard": render_dashboard,
 "Labour force & disability": render_labour,
 "Child labour": render_child,
 "Literacy & training": render_literacy,
 "Machine learning": render_ml,
 "Statistics & data quality": render_stats,
 "Chart studio": render_studio}[section]()
