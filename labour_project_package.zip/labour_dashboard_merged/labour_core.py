"""
labour_core.py - data access, analysis and chart functions shared by the Streamlit app and the notebook.

Covers the merged labour-force CSV (NCLS 2022 + LFS 2022 Ch.8 + DILFS 2022 Ch.4):
  * table readers   : tbl(), wide(), dil(), lfs()
  * question builders: q1_... q10_... (one per question in the project brief)
  * statistics      : male_female_tests(), trend_regression(), data_quality()
  * charts          : make_charts() -> 3D pie, 2D pie, bar, horizontal bar, stacked bar, 3D bar, 3D cylinder
The literacy / vocational-training dataset is handled by lfs_core.py (unchanged).
"""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy import stats

# Categorical palette, fixed order (validated default: blue, orange, aqua, yellow, magenta, green, violet, red)
PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
SEX_COLORS = {"Male": "#2a78d6", "Female": "#eb6834", "Total": "#8a8a85",
              "With disabilities": "#6250d6", "Without disabilities": "#1baf7a",
              # literacy / training dataset: disability = violet, general population = aqua, everywhere
              "Disabled": "#6250d6", "General": "#1baf7a"}
# hue = group, lightness = sex (used by the 3D duration chart)
GROUP_SEX_COLORS = {"Disabled-Female": "#6250d6", "Disabled-Male": "#9085e9",
                    "General-Female": "#1baf7a", "General-Male": "#7fd3b4"}
STYLES = ["3D pie", "2D pie", "Bar (vertical)", "Rectangular bar (horizontal)",
          "Stacked bar", "3D bar", "3D cylindrical bar"]
AGE_ORDER = ["15-24", "25-34", "35-44", "45-54", "55-64"]
AREAS = ["Rural", "Urban", "Bangladesh"]


# ---------- data access ------------------------------------------------------
def load_data(src):
    df = pd.read_csv(src, keep_default_na=False, encoding="utf-8-sig")
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df


def tbl(df, survey, table_id, unit=None):
    x = df[(df.survey == survey) & (df.table_id == table_id)]
    if unit is not None:
        x = x[x.unit == unit]
    return x


def wide(x, index="row_label"):
    """Pivot a long table to wide. Columns become (column_group, column_label) when groups exist."""
    has_group = (x["column_group"] != "").any()
    cols = ["column_group", "column_label"] if has_group else ["column_label"]
    w = x.pivot_table(index=index, columns=cols, values="value", sort=False, aggfunc="first")
    return w


def dil(df, table_id, unit):
    """DILFS table -> index: row_label, columns: Male/Female/Total."""
    return wide(tbl(df, "DILFS 2022", table_id, unit))


def lfs(df, table_id):
    """LFS table -> index: row_label, columns: (Rural|Urban|Bangladesh|Total, Male|Female|Total)."""
    w = wide(tbl(df, "LFS 2022", table_id))
    w.columns = pd.MultiIndex.from_tuples([("Bangladesh" if a == "Total" else a, b) for a, b in w.columns])
    return w


def icls_ids(icls):
    return {"13th": dict(lf="4.1.1", emp="4.2.1", une="4.3.1", out="4.4.1", rate="4.5.1", lfpr="4.12.1"),
            "19th": dict(lf="4.1.2", emp="4.2.2", une="4.3.2", out="4.4.2", rate="4.5.2", lfpr="4.12.2")}[icls]


# ---------- question builders ---------------------------------------------------
def q1_emp_unemp(df, icls="13th", disability="Total"):
    """Employed vs unemployed (thousand) by sex, filtered by disability status row."""
    ids = icls_ids(icls)
    e = dil(df, "Table " + ids["emp"], "thousands").loc[disability]
    u = dil(df, "Table " + ids["une"], "thousands").loc[disability]
    return pd.DataFrame({"Employed": e, "Unemployed": u}).T[["Male", "Female", "Total"]]


def q1_disabled_lf(df, icls="13th"):
    """Labour force with / without disabilities (thousand) by sex."""
    w = dil(df, "Table " + icls_ids(icls)["lf"], "thousands")
    return w.loc[["With disabilities", "Without disabilities"], ["Male", "Female", "Total"]]


def q1_disabled_status(df, icls="13th"):
    """Persons with disabilities: employed / unemployed by sex (thousand)."""
    return q1_emp_unemp(df, icls, "With disabilities")


def q2_age_area(df, measure="count"):
    """LFS: unemployed by age group x area x sex (count in thousand or rate %)."""
    return lfs(df, "Table 8.1.1" if measure == "count" else "Table 8.3.1")


def sex_area_summary(df):
    """Total male / female unemployed by area (merged-header style table, with totals)."""
    w = q2_age_area(df, "count")
    tot = w.loc[["Total"]].T.reset_index()
    tot.columns = ["Area", "Sex", "Unemployed (thousand)"]
    return tot.pivot(index="Sex", columns="Area", values="Unemployed (thousand)")[AREAS]


def participants_summary(df):
    """Headline participants by sex across the three surveys."""
    rows = []
    def add(label, w, row, unit):
        r = w.loc[row]
        rows.append(dict(Indicator=label, Unit=unit, Male=r["Male"], Female=r["Female"], Total=r["Total"]))
    add("Labour force (15+, 13th ICLS)", dil(df, "Table 4.1.1", "thousands"), "Total", "thousand")
    add("Employed", dil(df, "Table 4.2.1", "thousands"), "Total", "thousand")
    add("Unemployed", dil(df, "Table 4.3.1", "thousands"), "Total", "thousand")
    add("Outside labour force", dil(df, "Table 4.4.1", "thousands"), "Total", "thousand")
    add("Labour force WITH disabilities", dil(df, "Table 4.1.1", "thousands"), "With disabilities", "thousand")
    t = tbl(df, "NCLS 2022", "Table 4.5", "count")
    t = t[(t.row_label == "Total") & (t.column_group == "Total")]
    r = t.set_index("column_label")["value"]
    rows.append(dict(Indicator="Working children 5-17", Unit="persons", Male=r["Male"], Female=r["Female"], Total=r["Total"]))
    out = pd.DataFrame(rows)
    out["Female share %"] = (out["Female"] / out["Total"] * 100).round(1)
    return out


def dataset_structure(df):
    g = df.groupby("survey")
    out = pd.DataFrame({
        "tables/figures": g.table_id.nunique(),
        "rows (long format)": g.size(),
        "distinct row labels": g.row_label.nunique(),
        "column groups (merged headers)": g.column_group.apply(lambda s: s[s != ""].nunique()),
        "units": g.unit.apply(lambda s: ", ".join(sorted(set(s)))),
    })
    return out


def q3_outside_lf(df, icls="13th", measure="percent"):
    unit = "percent" if measure == "percent" else "thousands"
    w = dil(df, "Table " + icls_ids(icls)["out"], unit)
    return w.loc[["With disabilities", "Without disabilities"], ["Male", "Female", "Total"]]


def q4_unemp_rate(df, icls="13th"):
    w = dil(df, "Table " + icls_ids(icls)["rate"], "percent")
    return w[["Male", "Female", "Total"]]


def q4_participation(df, icls="13th"):
    lfpr = dil(df, "Table " + icls_ids(icls)["lfpr"], "percent")
    out = {"Labour force participation rate": lfpr}
    if icls == "13th":
        out["Employment-to-population ratio"] = dil(df, "Table 4.13", "percent")
    return out


def q5_sector(df):
    return dil(df, "Table 4.7", "percent").drop(index="Total")[["Male", "Female", "Total"]]


def q6_status(df):
    w = dil(df, "Table 4.6", "percent")
    t = dil(df, "Table 4.6", "thousands")
    self_emp = (w.loc[["Own account worker", "Employer"]].sum()).to_frame("Self-employed (own account + employer)").T
    return w.drop(index="Total"), t.drop(index="Total"), self_emp, dil(df, "Table 4.8", "percent").drop(index="Total")


def q8_unemp_by_education(df):
    return lfs(df, "Table 8.4.1"), lfs(df, "Table 8.2.1"), lfs(df, "Table 8.4.2")


def q9_child_industry(df):
    """Working children by industry: shares (%) within age groups, plus under-15 aggregate."""
    n = wide(tbl(df, "NCLS 2022", "Table 4.2", "count"))["Number"]
    tot = n.loc["Total"]
    n = n.drop(index="Total")
    n["Under 15 (5-13)"] = n["5-11"] + n["12-13"]
    shares = n.div(n.sum()) * 100
    shares.columns = [c if c != "Total" else "All 5-17" for c in shares.columns]
    n.columns = [c if c != "Total" else "All 5-17" for c in n.columns]
    return n, shares


def q10_school(df):
    n = wide(tbl(df, "NCLS 2022", "Table 4.6", "count"))["Number"].drop(index="Total")
    p = wide(tbl(df, "NCLS 2022", "Table 4.6", "proportion"))["Percent"].drop(index="Total") * 100
    return n, p


def q10_reasons(df, table_id):
    w = wide(tbl(df, "NCLS 2022", table_id, "proportion")).droplevel(0, axis=1).drop(index="Total") * 100
    return w


# ---------- statistics ------------------------------------------------------------
def male_female_tests(df):
    rows = []
    for name, tid in {"Age group (Table 8.3.1)": "Table 8.3.1", "Education (Table 8.4.1)": "Table 8.4.1"}.items():
        w = lfs(df, tid).drop(index="Total")
        for area in AREAS:
            m, f = w[(area, "Male")], w[(area, "Female")]
            t, p = stats.ttest_rel(m, f)
            try:
                pw = stats.wilcoxon(m, f).pvalue
            except ValueError:
                pw = np.nan
            rows.append({"Breakdown": name, "Area": area, "n groups": len(m),
                         "Mean male rate %": m.mean(), "Mean female rate %": f.mean(),
                         "Mean diff (M-F)": (m - f).mean(), "t": t, "p (paired t)": p, "p (Wilcoxon)": pw})
    return pd.DataFrame(rows).round(4)


def trend_table(df):
    x = tbl(df, "LFS 2022", "Figure 8.7")
    w = wide(x).droplevel(0, axis=1)
    def yr(s):
        a = s.split("-")
        return float(a[0]) + (0.5 if len(a) > 1 else 0)
    w.index = [yr(i) for i in w.index]
    labels = list(x.row_label.unique())
    return w, labels


def trend_regression(df):
    w, _ = trend_table(df)
    rows = []
    for c in w.columns:
        r = stats.linregress(w.index.values, w[c].values)
        rows.append({"Series": c, "slope (pp / year)": r.slope, "intercept": r.intercept,
                     "R²": r.rvalue ** 2, "p-value": r.pvalue, "n points": len(w)})
    return pd.DataFrame(rows).round(4)


def data_quality(df):
    blanks = (df.replace("", np.nan).isna().sum()).rename("blank cells").to_frame()
    key = ["survey", "table_id", "row_group", "row_label", "column_group", "column_label", "unit"]
    dups = int(df.duplicated(subset=key).sum())
    flagged = []
    d = df[(df.is_total_row == "N") & df.value.notna()]
    for (t, u), g in d.groupby(["table_id", "unit"]):
        if len(g) < 8:
            continue
        q1, q3 = g.value.quantile([.25, .75])
        iqr = q3 - q1
        hi = g[g.value > q3 + 1.5 * iqr]
        for _, r in hi.iterrows():
            flagged.append((r.survey, t, r.row_label, r.column_group, r.column_label, r.unit, r.value))
    out = pd.DataFrame(flagged, columns=["survey", "table", "row", "col group", "col", "unit", "value"])
    return blanks, dups, out


# ---------- charts ------------------------------------------------------------------
def short(s, n=34):
    s = str(s)
    return s if len(s) <= n else s[: n - 1] + "…"


def color_for(name, i, cmap=None):
    if cmap and name in cmap:
        return cmap[name]
    return SEX_COLORS.get(name, PALETTE[i % len(PALETTE)])


def _add_mesh(fig, V, F, color, name, hover, showlegend=False):
    V = np.array(V, float); F = np.array(F, int)
    fig.add_trace(go.Mesh3d(x=V[:, 0], y=V[:, 1], z=V[:, 2], i=F[:, 0], j=F[:, 1], k=F[:, 2],
                            color=color, flatshading=True, name=short(name, 40), legendgroup=name,
                            showlegend=showlegend, hovertext=hover, hoverinfo="text",
                            lighting=dict(ambient=0.55, diffuse=0.85, specular=0.25, roughness=0.6)))


def _slice(a0, a1, r=1.0, h=0.32, explode=0.0):
    n = max(6, int(round((a1 - a0) / (2 * np.pi) * 90)))
    ang = np.linspace(a0, a1, n + 1); mid = (a0 + a1) / 2
    ox, oy = explode * np.cos(mid), explode * np.sin(mid)
    V = [(ox, oy, h), (ox, oy, 0)]
    V += [(ox + r * np.cos(a), oy + r * np.sin(a), h) for a in ang]
    V += [(ox + r * np.cos(a), oy + r * np.sin(a), 0) for a in ang]
    T = lambda t: 2 + t
    B = lambda t: 2 + (n + 1) + t
    F = []
    for t in range(n):
        F += [(0, T(t), T(t + 1)), (1, B(t + 1), B(t)), (T(t), B(t), B(t + 1)), (T(t), B(t + 1), T(t + 1))]
    F += [(0, 1, B(0)), (0, B(0), T(0)), (0, T(n), B(n)), (0, B(n), 1)]
    return V, F


def _text_on(hex_color):
    """Black or white text, whichever has the higher WCAG contrast on the given fill."""
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    lin = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    L = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
    return "#ffffff" if 1.05 / (L + 0.05) >= (L + 0.05) / 0.054 else "#0b0b0b"


def pie3d(labels, values, title="", unit="", colors=None):
    labels = [str(l) for l in labels]; values = np.asarray(values, float)
    tot = values.sum(); fig = go.Figure()
    colors = colors or [color_for(l, i) for i, l in enumerate(labels)]
    a = np.pi / 2  # start at 12 o'clock
    lx, ly, lz, lt, lc = [], [], [], [], []
    for lab, v, c in zip(labels, values, colors):
        frac = v / tot if tot else 0
        if frac <= 0:
            continue
        a1 = a + 2 * np.pi * frac
        V, F = _slice(a, a1, explode=0.04)
        _add_mesh(fig, V, F, c, f"{lab} ({frac * 100:.1f}%)", f"{lab}<br>{v:,.2f} {unit}<br>{frac * 100:.1f}% of total", showlegend=True)
        if frac >= 0.015:
            mid = (a + a1) / 2
            inside = frac >= 0.08           # big slice: label on the top face, thin slice: just outside the rim
            rad = 0.6 if inside else 1.25
            lx.append(rad * np.cos(mid)); ly.append(rad * np.sin(mid)); lz.append(0.36 if inside else 0.2)
            lt.append(f"{frac * 100:.1f}%")
            lc.append(_text_on(c) if inside else "#52514e")
        a = a1
    fig.add_trace(go.Scatter3d(x=lx, y=ly, z=lz, mode="text", text=lt, textfont=dict(size=13, color=lc),
                               hoverinfo="skip", showlegend=False))
    ax = dict(visible=False)
    fig.update_layout(title=title, height=430, margin=dict(l=0, r=0, t=50, b=0),
                      scene=dict(xaxis=ax, yaxis=ax, zaxis=ax, aspectmode="manual",
                                 aspectratio=dict(x=1, y=1, z=0.35),
                                 camera=dict(eye=dict(x=0.0, y=-1.55, z=1.15))),
                      legend=dict(orientation="h", y=-0.02, x=0.5, xanchor="center"))
    return fig


def _box(cx, cy, h, w=0.32):
    V = [(cx - w, cy - w, 0), (cx + w, cy - w, 0), (cx + w, cy + w, 0), (cx - w, cy + w, 0),
         (cx - w, cy - w, h), (cx + w, cy - w, h), (cx + w, cy + w, h), (cx - w, cy + w, h)]
    F = [(0, 2, 1), (0, 3, 2), (4, 5, 6), (4, 6, 7), (0, 1, 5), (0, 5, 4), (1, 2, 6), (1, 6, 5),
         (2, 3, 7), (2, 7, 6), (3, 0, 4), (3, 4, 7)]
    return V, F


def _cyl(cx, cy, h, r=0.34, n=32):
    ang = np.linspace(0, 2 * np.pi, n, endpoint=False)
    V = [(cx, cy, h), (cx, cy, 0)]
    V += [(cx + r * np.cos(a), cy + r * np.sin(a), h) for a in ang]
    V += [(cx + r * np.cos(a), cy + r * np.sin(a), 0) for a in ang]
    F = []
    for i in range(n):
        j = (i + 1) % n
        F += [(0, 2 + i, 2 + j), (1, 2 + n + j, 2 + n + i), (2 + i, 2 + n + i, 2 + n + j), (2 + i, 2 + n + j, 2 + j)]
    return V, F


def _ar(nx, ny):
    """Equal unit spacing on x/y (so cylinders stay round), normalised so the scene fits the camera."""
    x, y = nx + 0.4, ny + 0.4
    z = max(nx, ny) * 0.55
    k = 1.7 / max(x, y, z)
    return dict(x=x * k, y=y * k, z=z * k)


def bars3d(df, title="", unit="", cylinder=False, cmap=None):
    cats = [short(c, 26) for c in df.index]; ser = [str(c) for c in df.columns]
    fig = go.Figure()
    for j, s in enumerate(ser):
        for i, c in enumerate(cats):
            v = df.iloc[i, j]
            if pd.isna(v):
                continue
            h = max(float(v), 1e-9)
            V, F = (_cyl if cylinder else _box)(i, j, h)
            _add_mesh(fig, V, F, color_for(s, j, cmap), s, f"{df.index[i]}<br>{s}: {v:,.2f} {unit}", showlegend=(i == 0))
    zmax = float(np.nanmax(df.values)) if df.size else 1
    fig.update_layout(
        title=title, height=520, margin=dict(l=0, r=0, t=50, b=0),
        scene=dict(
            xaxis=dict(title="", tickvals=list(range(len(cats))), ticktext=cats, tickfont=dict(size=10),
                       range=[-0.7, len(cats) - 0.3]),
            yaxis=dict(title="", tickvals=list(range(len(ser))), ticktext=ser, range=[-0.7, len(ser) - 0.3]),
            zaxis=dict(title=unit, range=[0, zmax * 1.08]),
            aspectmode="manual", aspectratio=_ar(len(cats), len(ser)),
            camera=dict(eye=dict(x=1.7, y=-1.9, z=0.9))),
        legend=dict(orientation="h", y=-0.02, x=0.5, xanchor="center"))
    return fig


def bars2d(df, title="", unit="", horizontal=False, stacked=False, cmap=None):
    fig = go.Figure()
    cats = [short(i, 42) if horizontal else str(i) for i in df.index]
    for j, c in enumerate(df.columns):
        c = str(c); vals = df.iloc[:, j]
        kw = dict(x=vals, y=cats, orientation="h") if horizontal else dict(x=cats, y=vals)
        fig.add_trace(go.Bar(name=c, marker_color=color_for(c, j, cmap),
                             hovertemplate="%{" + ("y" if horizontal else "x") + "}<br>" + c +
                             ": %{" + ("x" if horizontal else "y") + ":,.2f} " + unit + "<extra></extra>", **kw))
    fig.update_layout(title=title, barmode="stack" if stacked else "group", bargap=0.35, height=480,
                      margin=dict(l=10, r=10, t=50, b=10), legend=dict(orientation="h", y=-0.2),
                      xaxis_title=unit if horizontal else None, yaxis_title=None if horizontal else unit)
    if horizontal:
        fig.update_yaxes(autorange="reversed")
    return fig


def pie2d(labels, values, title="", unit="", cmap=None):
    labels = [str(l) for l in labels]
    fig = go.Figure(go.Pie(labels=labels, values=values, sort=False, textinfo="label+percent",
                           marker=dict(colors=[color_for(l, i, cmap) for i, l in enumerate(labels)],
                                       line=dict(color="white", width=2)),
                           hovertemplate="%{label}<br>%{value:,.2f} " + unit + "<extra></extra>", automargin=True))
    fig.update_layout(title=title, height=400, margin=dict(l=10, r=10, t=70, b=10), legend=dict(orientation="h"))
    return fig


def make_charts(df, style, title="", unit="", cmap=None):
    """df: index = categories, columns = series. Pie styles return one figure per column."""
    df = df.copy(); df.index = [str(i) for i in df.index]; df.columns = [str(c) for c in df.columns]
    if style in ("3D pie", "2D pie"):
        figs = []
        for c in df.columns:
            s = df[c].fillna(0); s = s[s > 0]
            t = f"{title} — {c}" if len(df.columns) > 1 else title
            figs.append(pie3d(s.index, s.values, t, unit, [color_for(l, i, cmap) for i, l in enumerate(s.index)])
                        if style == "3D pie" else pie2d(s.index, s.values, t, unit, cmap))
        return figs
    if style == "3D bar":
        return [bars3d(df, title, unit, cmap=cmap)]
    if style == "3D cylindrical bar":
        return [bars3d(df, title, unit, cylinder=True, cmap=cmap)]
    if style == "Rectangular bar (horizontal)":
        return [bars2d(df, title, unit, horizontal=True, cmap=cmap)]
    if style == "Stacked bar":
        return [bars2d(df, title, unit, stacked=True, cmap=cmap)]
    return [bars2d(df, title, unit, cmap=cmap)]


# ---------- helpers for the literacy / training dataset (lfs_core.py output) -------------------
LABOUR_REQUIRED = ["survey", "table_id", "table_title", "row_group", "row_label", "column_group",
                   "column_label", "unit", "value", "is_total_row"]
LITERACY_REQUIRED = ["Survey", "Table", "Table_Title", "Category", "Group", "Sex", "Value"]


def validate_columns(df, required, what):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"This does not look like the {what} file - missing column(s): {', '.join(missing)}")


def pair_table(d, order, sex="Total", loc="National"):
    """lfs_core.types()/durations() output -> Category x (General, Disabled) shares (%).
    The disability survey is national only, so Disabled always uses its national row."""
    g = d[(d.Pop == "General") & (d.Locality == loc) & (d.Sex == sex)]
    s = d[(d.Pop == "Disabled") & (d.Locality == "National") & (d.Sex == sex)]
    both = pd.concat([g, s])
    both = both.assign(Category=both.Category.astype(str))
    return both.pivot(index="Category", columns="Pop", values="Share").reindex(order).reindex(columns=["General", "Disabled"])


def duration_group_sex(d, order):
    """Duration x (Disabled-Female, Disabled-Male, General-Female, General-Male), national, shares (%)."""
    cols = {}
    for p, s in [("Disabled", "Female"), ("Disabled", "Male"), ("General", "Female"), ("General", "Male")]:
        x = d[(d.Pop == p) & (d.Locality == "National") & (d.Sex == s)]
        cols[f"{p}-{s}"] = x.assign(Category=x.Category.astype(str)).set_index("Category").Share.reindex(order)
    return pd.DataFrame(cols)


def literacy_quality(d2):
    key = ["Survey", "Table", "Category", "Group", "Sex"]
    return dict(rows=len(d2), tables=d2.groupby("Source").Table.nunique().to_dict(),
                missing=int(d2.Value.isna().sum()), duplicates=int(d2.duplicated(subset=key).sum()))
