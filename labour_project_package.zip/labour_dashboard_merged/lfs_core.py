"""Shared data preparation for the DILFS 2022 vs LFS 2022 project (report + dashboard)."""
import numpy as np
import pandas as pd

SEED = 42
TYPE_MAP = {  # LFS 2022 label -> harmonised label (None = goes to Other)
    "Computer": "Computer",
    "Craftsman/handicraft and cottage work": "Craft/handicraft",
    "Creative arts/artists/photography": "Creative arts",
    "Agriculture crop production and preserve": "Crop agriculture",
    "Non-crop agricultural activities": "Non-crop agriculture",
    "Health and paramedical services": "Health/paramedical",
    "Driving and motor mechanic": "Driving/motor mechanic",
    "Foreign language": "Foreign language",
    "Construction related works": "Construction",
    "Ready-made Garments (RMG)": "RMG",
    "Other": "Other",
}
DILFS_TYPE_MAP = dict(TYPE_MAP)
DUR_MAP = {"< 1 week": "<1 week", "1-2 Weeks": "1-2 weeks", "3-4 Weeks": "3-4 weeks",
           "1-3 Months": "1-3 months", "4-6 Months": "4-6 months", "> 6 months": ">6 months"}
DUR_ORDER = ["<1 week", "1-2 weeks", "3-4 weeks", "1-3 months", "4-6 months", ">6 months"]
TYPE_ORDER = ["Computer", "Crop agriculture", "RMG", "Foreign language", "Health/paramedical",
              "Craft/handicraft", "Driving/motor mechanic", "Construction", "Creative arts",
              "Non-crop agriculture", "Other"]


def load(path):
    df = pd.read_csv(path, encoding="utf-8-sig", keep_default_na=False, na_values=[""])
    df["Source"] = df.Survey.str.split(" - ").str[0]
    df["Pop"] = np.where(df.Source.str.startswith("DILFS"), "Disabled", "General")
    df["Locality"] = df.Group.replace({"Bangladesh": "National"})
    df.loc[df.Pop == "Disabled", "Locality"] = "National"
    return df


def literacy_table(df):
    """Literacy rate (%) by population and sex (national, all ages)."""
    d = df[(df.Table == "3.1") & (df.Category == "Literate")][["Sex", "Value"]].assign(Pop="Disabled")
    g = df[(df.Table == "4.1.1") & (df.Category == "Total") & (df.Locality == "National")][["Sex", "Value"]].assign(Pop="General")
    both = pd.concat([d, g])
    w = both.pivot(index="Sex", columns="Pop", values="Value").loc[["Male", "Female", "Total"]]
    w["Gap"] = w.General - w.Disabled
    return w


def literacy_age(df):
    g = df[(df.Table == "4.1.1") & (df.Locality == "National") & (df.Category != "Total")]
    return g.pivot(index="Category", columns="Sex", values="Value")[["Male", "Female", "Total"]]


def literacy_locality(df):
    g = df[(df.Table == "4.1.1") & (df.Category == "Total") & (df.Locality.isin(["Rural", "Urban", "National"]))]
    return g.pivot(index="Locality", columns="Sex", values="Value")[["Male", "Female", "Total"]]


def _shares(df, table_d, table_g, catmap, order, pct_only=True):
    d = df[(df.Table == table_d) & (df.Category != "Total")].copy()
    g = df[(df.Table == table_g) & (df.Category != "Total")].copy()
    d["Cat"] = d.Category.map(catmap); g["Cat"] = g.Category.map(catmap).fillna("Other")
    d["Cat"] = d.Cat.fillna("Other")
    out = pd.concat([d[["Pop", "Locality", "Sex", "Cat", "Value"]], g[["Pop", "Locality", "Sex", "Cat", "Value"]]])
    out = out.groupby(["Pop", "Locality", "Sex", "Cat"], as_index=False).Value.sum()
    out = out.rename(columns={"Cat": "Category", "Value": "Share"})
    out["Category"] = pd.Categorical(out.Category, order, ordered=True)
    return out.sort_values(["Pop", "Locality", "Sex", "Category"]).reset_index(drop=True)


def types(df):
    return _shares(df, "3.5", "4.3.3", TYPE_MAP, TYPE_ORDER)


def durations(df):
    d = df[(df.Table == "3.4")].copy()
    g = df[(df.Table == "4.3.2")].copy()
    d["Category"] = d.Category.replace({"<1 week": "<1 week"})
    g["Category"] = g.Category.map(DUR_MAP)
    keep = ["Pop", "Locality", "Sex", "Category", "Value"]
    out = pd.concat([d[keep], g[keep]])
    out = out[out.Category != "Total"].rename(columns={"Value": "Share"}).dropna(subset=["Category"])
    out["Category"] = pd.Categorical(out.Category, DUR_ORDER, ordered=True)
    return out.sort_values(["Pop", "Locality", "Sex", "Category"]).reset_index(drop=True)


def training_rate(df):
    d = df[(df.Table == "3.3") & (df.Category == "Yes") & (df.Group == "In percentage (%)")][["Sex", "Value"]].assign(Pop="Disabled")
    g = df[(df.Table == "4.3.1") & (df.Category == "Yes") & (df.Locality == "National")][["Sex", "Value"]].assign(Pop="General")
    return pd.concat([d, g]).pivot(index="Sex", columns="Pop", values="Value").loc[["Male", "Female", "Total"]]


def sources(df):
    d = df[(df.Table == "3.6") & (df.Category != "Total")].copy()
    g = df[(df.Table == "4.3.4") & (df.Category != "Total")].copy()
    m = {"Government Institute": "Government", "Private Institute": "Private", "NGO": "NGO", "Foreign Institute": "Foreign",
         "Joint Venture Institute": "Joint venture", "Joint venture Institute": "Joint venture", "Others Institute": "Others"}
    for x in (d, g): x["Category"] = x.Category.map(m)
    out = pd.concat([d, g[g.Locality == "National"]])
    out = out[out.Sex == "Total"]
    return out.pivot_table(index="Category", columns="Pop", values="Value", sort=False)


def ml_frame(df):
    """Rows: percentage share of one category for Pop x Sex x Locality (Total sex dropped)."""
    t = types(df).assign(Topic="Type"); d = durations(df).assign(Topic="Duration")
    m = pd.concat([t, d], ignore_index=True)
    m = m[m.Sex != "Total"].copy()
    m["Category"] = m.Category.astype(str)
    m["is_disabled"] = (m.Pop == "Disabled").astype(int)
    m["is_female"] = (m.Sex == "Female").astype(int)
    m["is_rural"] = (m.Locality == "Rural").astype(int)
    m["is_urban"] = (m.Locality == "Urban").astype(int)
    m["female_x_disabled"] = m.is_female * m.is_disabled
    return m.reset_index(drop=True)


# ----------------------------------------------------------------------------- ML
def outliers(m):
    rows = []
    for topic, g in m.groupby("Topic"):
        q1, q3 = g.Share.quantile([.25, .75]); iqr = q3 - q1
        lo, hi = max(0.0, q1 - 1.5 * iqr), q3 + 1.5 * iqr
        z = (g.Share - g.Share.mean()) / g.Share.std(ddof=0)
        rows.append(dict(Topic=topic, Lower=lo, Upper=hi, IQR_outliers=int(((g.Share < lo) | (g.Share > hi)).sum()),
                         Z_outliers=int((z.abs() > 3).sum())))
    return pd.DataFrame(rows)


def cap(m):
    m = m.copy(); m["Share_raw"] = m.Share
    for topic, g in m.groupby("Topic"):
        q1, q3 = g.Share.quantile([.25, .75]); iqr = q3 - q1
        lo, hi = max(0.0, q1 - 1.5 * iqr), q3 + 1.5 * iqr
        m.loc[g.index, "Share"] = g.Share.clip(lo, hi)
    return m


def design(m):
    base = ["is_disabled", "is_female", "is_rural", "is_urban", "female_x_disabled"]
    X = pd.concat([m[base], pd.get_dummies(m.Category).astype(int)], axis=1)
    return X, m.Share


def run_ml(df):
    from sklearn.linear_model import LinearRegression, Ridge, Lasso
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split, cross_val_score, KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

    m0 = ml_frame(df); out_tab = outliers(m0); m = cap(m0)
    X, y = design(m)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=SEED)
    sc = StandardScaler().fit(Xtr); Xtr_s, Xte_s = sc.transform(Xtr), sc.transform(Xte)
    models = {
        "Linear Regression": LinearRegression(), "Ridge Regression": Ridge(alpha=1.0),
        "Lasso Regression": Lasso(alpha=0.01, max_iter=10000),
        "Decision Tree": DecisionTreeRegressor(max_depth=6, random_state=SEED),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=SEED)}
    res, cv, preds = [], [], {}
    kf = KFold(5, shuffle=True, random_state=SEED)
    for n, mod in models.items():
        mod.fit(Xtr_s, ytr); p = mod.predict(Xte_s); preds[n] = p
        mse = mean_squared_error(yte, p)
        res.append(dict(Model=n, MSE=mse, RMSE=mse ** .5, MAE=mean_absolute_error(yte, p), R2=r2_score(yte, p)))
        s = cross_val_score(make_pipeline(StandardScaler(), type(mod)(**mod.get_params())), X, y, cv=kf, scoring="r2")
        cv.append(dict(Model=n, Mean_R2=s.mean(), Std=s.std()))
    res = pd.DataFrame(res).sort_values("RMSE").reset_index(drop=True); cv = pd.DataFrame(cv)
    rf = models["Random Forest"]
    imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
    lasso_zero = int((models["Lasso Regression"].coef_ == 0).sum())
    # tree depth study
    depth = []
    for d in list(range(1, 11)) + [None]:
        t = DecisionTreeRegressor(max_depth=d, random_state=SEED).fit(Xtr_s, ytr)
        s = cross_val_score(make_pipeline(StandardScaler(), DecisionTreeRegressor(max_depth=d, random_state=SEED)), X, y, cv=kf, scoring="r2")
        depth.append(dict(Depth=("Full" if d is None else d), Train_R2=t.score(Xtr_s, ytr), Test_R2=t.score(Xte_s, yte), CV_R2=s.mean()))
    depth = pd.DataFrame(depth)
    # 3D grid: depth x min_samples_leaf -> CV R2
    grid = []
    for d in range(1, 9):
        for leaf in (1, 2, 3, 5, 8):
            s = cross_val_score(DecisionTreeRegressor(max_depth=d, min_samples_leaf=leaf, random_state=SEED), X, y, cv=kf, scoring="r2")
            grid.append(dict(Depth=d, MinLeaf=leaf, CV_R2=s.mean()))
    grid = pd.DataFrame(grid)
    small = DecisionTreeRegressor(max_depth=3, random_state=SEED).fit(Xtr, ytr)
    return dict(frame=m, outliers=out_tab, X=X, y=y, Xtr=Xtr, Xte=Xte, ytr=ytr, yte=yte, results=res, cv=cv,
                preds=preds, importance=imp, depth=depth, grid=grid, lasso_zero=lasso_zero, models=models,
                small_tree=small, n_train=len(Xtr), n_test=len(Xte), n_feat=X.shape[1])
