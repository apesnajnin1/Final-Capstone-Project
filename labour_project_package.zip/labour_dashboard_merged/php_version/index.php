<?php
$D=json_decode(file_get_contents(__DIR__.'/data.json'),true);
$surveys=array_values(array_unique(array_column($D,'s')));
$s=$_POST['sv']??$surveys[0];$tabs=array_values(array_filter($D,fn($t)=>$t['s']===$s));
$ti=min((int)($_POST['tb']??0),count($tabs)-1);$t=$tabs[$ti];$ri=(int)($_POST['rw']??0)-1;
$bv=(isset($_POST['bv'])&&is_numeric($_POST['bv']))?(float)$_POST['bv']:null;$bl=htmlspecialchars($_POST['bl']??'')?:'Benchmark';
$ct=in_array($_POST['ct']??'',['bar','line','horizontal'])?$_POST['ct']:'bar';
$idx=$ri<0?array_keys($t['r']):[min($ri,count($t['r'])-1)];
$vals=[];foreach($idx as $i)foreach($t['m'][$i] as $v)if($v!==null)$vals[]=$v;
$mean=array_sum($vals)/count($vals);$above=$bv===null?null:count(array_filter($vals,fn($v)=>$v>$bv));
function sel($n,$o,$cur){echo "<select name=$n onchange=\"this.form.submit()\">";foreach($o as $k=>$v)echo '<option value="'.$k.'"'.($k==$cur?' selected':'').'>'.htmlspecialchars($v).'</option>';echo '</select>';}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Labour ERP (PHP)</title><style>
:root{--bg:#f4f6fa;--card:#fff;--tx:#1d2433;--mu:#667085;--bd:#dfe3ec;--sb:#1b2a41;--sbt:#c9d3e3;--ac:#2f6fed;--ac2:#e0702d}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#10151f;--card:#182030;--tx:#e6eaf2;--mu:#98a2b3;--bd:#2a3448;--sb:#0b101a;--ac:#6b9bff}}
*{box-sizing:border-box}html,body{height:100%;margin:0}body{font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--bg);color:var(--tx);display:flex}
aside{width:230px;background:var(--sb);color:var(--sbt);padding:18px 0;flex-shrink:0;overflow:auto}
aside h1{font-size:15px;margin:0 18px 16px;color:#fff;letter-spacing:.3px}aside h1 small{display:block;font-weight:400;color:#8fa0bb;font-size:11px}
aside a{display:block;padding:9px 18px;color:var(--sbt);text-decoration:none;border-left:3px solid transparent;cursor:pointer}
aside a.on,aside a:hover{background:rgba(255,255,255,.07);border-color:var(--ac2);color:#fff}
main{flex:1;min-width:0;overflow:auto;padding:20px 24px}
h2{margin:0 0 14px;font-size:18px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:14px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px}
label{display:block;font-size:12px;color:var(--mu);margin-bottom:3px}
select,input,button{width:100%;padding:8px;border:1px solid var(--bd);border-radius:7px;background:var(--bg);color:var(--tx);font:inherit}
button{background:var(--ac);color:#fff;border:0;cursor:pointer;font-weight:600}
.kpi b{display:block;font-size:22px}.kpi span{color:var(--mu);font-size:12px}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:6px 9px;border-bottom:1px solid var(--bd);text-align:right;white-space:nowrap}
th:first-child,td:first-child{text-align:left}th{background:var(--bg);position:sticky;top:0}td.hi{background:rgba(47,111,237,.15);font-weight:600}
.ch{position:relative;height:330px}.note{color:var(--mu);font-size:12px}
@media(max-width:700px){body{flex-direction:column}aside{width:100%;display:flex;overflow-x:auto;padding:8px 0}aside h1{display:none}aside a{white-space:nowrap;border-left:0;border-bottom:3px solid transparent}}
</style></head><body>
<aside><h1>Labour ERP<small>PHP · Bangladesh 2022</small></h1><?php foreach($surveys as $x):?><a class="<?=$x===$s?'on':''?>" href="#" onclick="document.getElementById('sv').value='<?=$x?>';document.getElementById('tb').value=0;document.forms[0].submit();return false"><?=$x?></a><?php endforeach;?></aside>
<main><h2><?=htmlspecialchars($s.' · '.$t['id'].' ('.$t['u'].')')?></h2>
<form method="post" class="grid card"><input type="hidden" id="sv" name="sv" value="<?=htmlspecialchars($s)?>">
<div><label>Table</label><?php sel('tb',array_map(fn($x)=>$x['id'].' – '.substr($x['t'],0,60),$tabs),$ti);?></div>
<div><label>Series (row)</label><?php sel('rw',array_merge(['All rows'],$t['r']),$ri+1);?></div>
<div><label>Chart type</label><?php sel('ct',['bar'=>'Bar','line'=>'Line','horizontal'=>'Horizontal bar'],$ct);?></div>
<div><label>Your benchmark value</label><input name="bv" type="number" step="any" value="<?=$bv?>"></div>
<div><label>Benchmark label</label><input name="bl" value="<?=$bl?>"></div><div style="align-self:end"><button>Apply</button></div></form>
<div class="grid"><?php foreach([['Min',min($vals)],['Max',max($vals)],['Mean',round($mean,2)],['Cells',count($vals)]] as $k):?><div class="card kpi"><b><?=$k[1]?></b><span><?=$k[0]?></span></div><?php endforeach;?>
<?php if($above!==null):?><div class="card kpi"><b><?=$above?> / <?=count($vals)?></b><span>above <?=$bl?> (<?=$bv?>)</span></div><?php endif;?></div>
<div class="card" style="margin-bottom:14px"><div class="ch"><canvas id="cv"></canvas></div></div>
<div class="card tw"><table><tr><th>Row</th><?php foreach($t['c'] as $c)echo '<th>'.htmlspecialchars($c).'</th>';?></tr>
<?php foreach($idx as $i):?><tr><td><?=htmlspecialchars($t['r'][$i])?></td><?php foreach($t['m'][$i] as $v):?><td class="<?=($bv!==null&&$v!==null&&$v>$bv)?'hi':''?>"><?=$v===null?'–':number_format($v,2)?></td><?php endforeach;?></tr><?php endforeach;?></table></div></main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script><script>
const t=<?=json_encode($t)?>,idx=<?=json_encode($idx)?>,bv=<?=json_encode($bv)?>,bl=<?=json_encode($bl)?>,typ=<?=json_encode($ct)?>,pal=['#2f6fed','#e0702d','#2a9d8f','#8e5bd6','#d64550','#7a8b99','#c9a227'];
const ds=idx.map((i,n)=>({label:t.r[i],data:t.m[i],backgroundColor:pal[n%7],borderColor:pal[n%7]}));
if(bv!==null)ds.push({type:'line',label:bl,data:t.c.map(()=>bv),borderColor:'#d64550',borderDash:[6,4],pointRadius:0});
new Chart(document.getElementById('cv'),{type:typ=='horizontal'?'bar':typ,data:{labels:t.c,datasets:ds},options:{indexAxis:typ=='horizontal'?'y':'x',maintainAspectRatio:false}});
</script></body></html>